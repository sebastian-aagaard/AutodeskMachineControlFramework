import{l as o,a as r}from"../chunks/B6Z-pKTi.js";export{o as load_css,r as start};
