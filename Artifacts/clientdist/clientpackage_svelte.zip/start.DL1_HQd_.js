import{l as o,a as r}from"../chunks/9v7pKv-a.js";export{o as load_css,r as start};
