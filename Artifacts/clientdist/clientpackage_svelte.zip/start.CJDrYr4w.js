import{l as o,a as r}from"../chunks/__MiKEDs.js";export{o as load_css,r as start};
